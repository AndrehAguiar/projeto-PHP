 <h1>Verifica D&uacute;vidas</h1>

<form action="settings/login.php" method="post">
    <h2>Login</h2>
    <label for="email">Email: </label>
    <br>
    <input type="text" name="email" id="email">

    <br><br>

    <label for="password">Senha: </label>
    <br>
    <input type="password" name="password" id="password">
    <br><br>

    <input type="submit" value="Entrar"> 
</form>
<div id="link_form">
    <h5>Confirme as informa&ccedil;&otilde;es ou cadastre&#45;se.</h5>
    <a href="?p=cadastro&usuario=novo">Cadastrar </a> &#124;
    <a href=""> Esqueci a senha </a>
</div>
        