<?php
 
// constantes com as credenciais de acesso ao banco MySQL
define('DB_HOST', 'mysql.hostinger.com.br');
define('DB_USER', 'u494260651_5tig');
define('DB_PASS', 'testehost');
define('DB_NAME', 'u494260651_verdu');
 
// habilita todas as exibições de erros
ini_set('display_errors', true);
error_reporting(E_ALL);
 
// inclui o arquivo de funçõees
require_once 'functions.php';