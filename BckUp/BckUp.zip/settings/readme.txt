Pasta destinada para armazenamento das configurações gerais do site, tais como:
	- caminhos de diretórios padrões
	- 