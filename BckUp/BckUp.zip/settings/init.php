<?php
 
// constantes com as credenciais de acesso ao banco MySQL
define('DB_HOST', 'mysql.hostinger.com.br');
define('DB_USER', 'u347189519_andre');
define('DB_PASS', 'HOSTbd5TIG');
define('DB_NAME', 'u347189519_verdu');
 
// habilita todas as exibições de erros
ini_set('display_errors', true);
error_reporting(E_ALL);
 
// inclui o arquivo de funçõees
require_once 'functions.php';