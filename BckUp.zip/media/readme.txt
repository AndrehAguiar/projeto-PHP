Pasta destinada para armazenamento das mídias (imagens, vídeos, etc) exibidas no site

* * * ATENÇÃO * * *
Verificar se as imagens da galeria e notícias também serão armazenadas aqui ou em outro diretório mais específico